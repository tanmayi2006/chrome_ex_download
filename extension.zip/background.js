chrome.runtime.onMessage.addListener((o, i, r) => {
  if (o.action === "downloadImages")
    return chrome.tabs.query({ active: !0, currentWindow: !0 }, (e) => {
      var a;
      (a = e[0]) != null && a.id ? chrome.tabs.sendMessage(e[0].id, { action: "downloadImages" }, (t) => {
        r(t);
      }) : r({ message: "No active tab found" });
    }), !0;
  if (o.action === "downloadTables")
    return chrome.tabs.query({ active: !0, currentWindow: !0 }, (e) => {
      var a;
      (a = e[0]) != null && a.id ? chrome.tabs.sendMessage(e[0].id, { action: "downloadTables" }, (t) => {
        r(t);
      }) : r({ message: "No active tab found" });
    }), !0;
});
